import React, { useEffect } from "react";
import { useRoutes } from "react-router-dom";
import Routes from "./Routes";
import NavBar from "./Components/GolobalComponents/NavBar/NavBar";
import Header from "./Components/GolobalComponents/Header/Header";
import SectionsGenres from "./Components/GolobalComponents/SectionsGenres/SectionsGenres";
import "swiper/css/bundle";

export default function App() {
  const router = useRoutes(Routes);
  useEffect(() => {
    // console.clear();
  }, []);

  return (
    <>
      {/* <HumbergerBtn></HumbergerBtn> */}
      <NavBar></NavBar>
      <Header></Header>
      <SectionsGenres></SectionsGenres>

      {router}
    </>
  );
}
