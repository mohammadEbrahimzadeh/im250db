import React, { useEffect, useState } from "react";
// import { useSearchParams } from "react-router-dom";
// import GetAboutFilmsApi from "./../../Apis/GetAboutFilmsApi";
// import { AiOutlineApartment } from "react-icons/ai";
// import { FaImdb } from "react-icons/fa";
// import { GiEarthAmerica, GiDirectorChair } from "react-icons/gi";
// import { BsCalendarCheck, BsFillPenFill } from "react-icons/bs";
// import { MdOutlineHowToVote, MdRecentActors } from "react-icons/md";
// import { BiTime } from "react-icons/bi";
// import { Swiper, SwiperSlide } from "swiper/react";
// import { FreeMode, Navigation, Thumbs } from "swiper";
// import "swiper/css";
// import "swiper/css/free-mode";
// import "swiper/css/navigation";
// import "swiper/css/thumbs";
export default function AboutFilm() {
  // با تغییر ایدی در ادر مرور گر لاگ گرفته شود !هربار
  // اکنون فقط یکبار لاگ گرفته میشود بدون ری رندر
  useEffect(() => {
    console.log("url change");
  }, []);
  // const [searchParams] = useSearchParams();
  // const [thumbsSwiper, setThumbsSwiper] = useState(null);
  // const [IdFilm, setIdFilm] = useState();
  // const [url, seturl] = useState();
  // const [Film, setFilm] = useState();
  // let urlx = window.location.pathname;
  // urlx = urlx.substring(urlx.indexOf(":") + 1);
  // seturl(searchParams);

  // useEffect(() => {
  //   console.log(urlx);
  // }, []);

  // useEffect(() => {
  //   console.log("urlx");
  //   console.log(searchParams); // ▶ URLSearchParams {}
  // }, [searchParams]);
  // function SearchbyIdFilms() {
  //   const TwelveTopImdbPromise = Promise.resolve(GetAboutFilmsApi());
  //   TwelveTopImdbPromise.then((value) => {
  //     setFilm(value);
  //   });
  // }

  return (
    <div className="PageNationFilmsHome  p-sm-5 col-12 ">
      {/* {Film
        ? Film.map((item) => {

            return (
              <div
                key={item.id}
                className="col-12 d-flex gap-4    p-3 mainDivCardPagtion"
              >
                <div className=" col-3  ">
                  <img src={item.poster} className="w-100  " alt="" />
                </div>
                <div className=" col-9 d-flex  justify-content-evenly flex-column ">
                  <h2>{item.title}</h2>
                  <div className="d-flex align-items-center  gap-1">
                    <p className="m-0 p-0">
                      <AiOutlineApartment></AiOutlineApartment>
                    </p>
                    <p className=" m-0  me-3 ">
                      {" "}
                      {item.genres[1]} {item.genres[2]} {item.genres[3]}
                    </p>
                    <p className="m-0 p-0 text-center ">
                      <BsCalendarCheck></BsCalendarCheck>
                    </p>{" "}
                    <p className=" m-0  me-3">{item.year}</p>
                    <p className="m-0 p-0">
                      <GiEarthAmerica></GiEarthAmerica>{" "}
                    </p>{" "}
                    <p className=" me-3 m-0  ">{item.country}</p>
                  </div>{" "}
                  <hr />{" "}
                  <div className="d-flex gap-1  col-11  ">
                    {" "}
                    <p className="m-0 p-0">
                      <FaImdb></FaImdb>
                    </p>
                    <p className="mt-1">{item.imdb_rating}</p>
                    <p className="m-0 p-0">
                      <MdOutlineHowToVote></MdOutlineHowToVote>
                    </p>
                    <p className="mt-1">{item.imdb_votes}</p>
                    <p className="m-0 p-0">
                      <BiTime></BiTime>
                    </p>
                    <p className="mt-1">{item.runtime}</p>
                  </div>{" "}
                  <div className="d-flex flex-column gap-1  col-11  ">
                    {" "}
                    <div className="d-flex gap-2">
                      <p className="m-0 p-0">
                        <MdRecentActors></MdRecentActors>
                      </p>
                      <p className="mt-0 p-0">Actors: </p>
                      <p className="mt-0">{item.actors}</p>
                    </div>
                    <div className="d-flex gap-2">
                      <p className="m-0 p-0">
                        <GiDirectorChair></GiDirectorChair>
                      </p>
                      <p className="m-0 p-0">Director: </p>
                      <p className="mt-0">{item.director}</p>
                    </div>
                    <div className="d-flex gap-2">
                      <p className="m-0 p-0">
                        <BsFillPenFill></BsFillPenFill>
                      </p>
                      <p className="m-0 p-0">Writer: </p>
                      <p className="mt-0">{item.writer}</p>
                    </div>
                  </div>{" "}
                  <div className="SwiperDiv my-3 col-10   d-flex justify-content-center ">
                    <div className="h-100 col-12 ">
                      <Swiper
                        style={{
                          "--swiper-navigation-color": "#fff",
                          "--swiper-pagination-color": "#fff",
                        }}
                        loop={true}
                        spaceBetween={10}
                        thumbs={{ swiper: thumbsSwiper }}
                        modules={[FreeMode, Navigation, Thumbs]}
                        className="mySwiper2"
                      >
                        {" "}
                        <SwiperSlide>
                          <img src={item.images[0]} />
                        </SwiperSlide>
                        <SwiperSlide>
                          <img src={item.images[1]} />
                        </SwiperSlide>
                        <SwiperSlide>
                          <img src={item.images[2]} />
                        </SwiperSlide>
                      </Swiper>
                      <Swiper
                        onSwiper={setThumbsSwiper}
                        loop={true}
                        spaceBetween={10}
                        slidesPerView={4}
                        freeMode={true}
                        watchSlidesProgress={true}
                        modules={[FreeMode, Navigation, Thumbs]}
                        className="mySwiper"
                      >
                        <SwiperSlide>
                          <img src={item.images[0]} />
                        </SwiperSlide>
                        <SwiperSlide>
                          <img src={item.images[1]} />
                        </SwiperSlide>
                        <SwiperSlide>
                          <img src={item.images[2]} />
                        </SwiperSlide>
                      </Swiper>
                    </div>
                  </div>
                </div>
              </div>
            );
        
        })
        : ""} */}
    </div>
  );
}
